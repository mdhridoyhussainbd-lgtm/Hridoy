# Hridoy Hussain: Personal Website

Personal website of **Hridoy Hussain**: social media, short-form video and WordPress for healthcare brands, and host of the **Hridoy Hussain Podcast**.

Live site: https://hridoy.webworkmedia.com/

## Features

- **3D hero logo:** the HH monogram, rendered with three.js. It falls back to an SVG logo when WebGL is not available.
- **Automatic language:** visitors whose device uses Bangladesh time or Bangla see a mixed Bangla-English version. Everyone else sees English. The `EN | বাং` switch lets visitors change it, and the choice is remembered.
- **Two ways to hire:** clients outside Bangladesh are sent to Upwork, and clients in Bangladesh to WhatsApp.
- **Podcast guest applications:** the contact form turns answers into a ready-to-send WhatsApp message.
- **Pure HTML, CSS and JS:** no build step or framework. three.js loads from cdnjs.
- **SEO:** meta tags, Open Graph, `Person` structured data, `robots.txt` and `sitemap.xml`.

## Structure

```
index.html            Page markup (English text, with data-i18n keys)
assets/css/style.css  All styles (brand tokens at the top)
assets/js/main.js     Language switch, 3D logo, animations, contact form
assets/images/        Photos, portfolio covers, podcast cover, favicon
404.html              Not-found page
robots.txt, sitemap.xml
```

## Editing

| What | Where |
|---|---|
| English text | Directly in `index.html` |
| Bangla text | The `BN` object at the top of `assets/js/main.js` (same keys as `data-i18n` in the HTML) |
| Colours and fonts | `:root` at the top of `assets/css/style.css` |
| WhatsApp number | `WA` in `assets/js/main.js` and the phone number in `index.html` |
| Upwork link | Search `upwork.com/freelancers` in `index.html` |

## Run locally

Open `index.html` in a browser, or serve the folder:

```bash
python -m http.server 8000
```

## Deploy

**Your own hosting (cPanel / FTP):** upload everything in this folder to the site's `public_html` (or subdomain) folder.

**GitHub Pages:** go to the repo, then *Settings → Pages → Deploy from a branch → `main` / root*. To use the custom domain, add it under *Custom domain* and point a `CNAME` DNS record for `hridoy` to `<your-username>.github.io`.

## Brand

Monochrome palette (#0E0E0E, #1B1B1B, #6B6B6B, #D9D9D9, #FFFFFF), Montserrat, silver HH monogram. See the brand kit for the full guidelines.

© Hridoy Hussain. All rights reserved. Photos and brand assets may not be reused without permission.
